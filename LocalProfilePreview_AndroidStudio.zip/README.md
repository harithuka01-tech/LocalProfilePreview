# Local Profile Preview

Eine eigenständige Android-Studio-Demo, die das gewünschte Profil-UI nachbildet.

Enthalten:
- lokale Trophäenanzeige
- Prestige-I/II-Umschalter
- Landscape-Layout ähnlich der gezeigten Profilansicht
- keine Verbindung zu Null's Brawl
- keine Änderung von Account- oder Serverdaten

## Öffnen
ZIP entpacken und den Ordner in Android Studio öffnen.
Danach Gradle synchronisieren und die `app`-Konfiguration starten.
