package com.example.localprofilepreview

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var prestigeEnabled = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val trophiesView = findViewById<TextView>(R.id.trophiesView)
        val prestigeView = findViewById<TextView>(R.id.prestigeView)
        val input = findViewById<EditText>(R.id.trophyInput)
        val applyButton = findViewById<Button>(R.id.applyButton)
        val prestigeButton = findViewById<Button>(R.id.prestigeButton)

        applyButton.setOnClickListener {
            val value = input.text.toString().toLongOrNull()
            if (value != null && value >= 0) {
                trophiesView.text = "$value 🏆"
            } else {
                input.error = "Bitte eine gültige Zahl eingeben."
            }
        }

        prestigeButton.setOnClickListener {
            prestigeEnabled = !prestigeEnabled
            prestigeView.text = if (prestigeEnabled) {
                "106 / 106 gesammelt • Prestige II"
            } else {
                "106 / 106 gesammelt • Prestige I"
            }
        }
    }
}
